﻿using System;
using System.Text;
using Crestron.SimplSharp;
using Crestron.SimplSharp.Net.Http;

namespace Flic_Integration
{
	#region Classes
	//Event Classes
	public class SerialChangeEventArgs : EventArgs
	{
		public string Button_ID { get; set; }
		public string Button_State { get; set; }

		public SerialChangeEventArgs()
		{
		}

		public SerialChangeEventArgs(string Button_ID, string Button_State)
		{
			#region Set Class Data Elements from Parameters
			this.Button_ID = Button_ID;
			this.Button_State = Button_State;
			#endregion
		}
	}

	public static class SignalChangeEvents
	{
		public static event SerialChangedEventHandler onSerialValueChange;

		public static void SerialValueChange(string Button_ID, string Button_State)
		{
			SignalChangeEvents.onSerialValueChange(new SerialChangeEventArgs(Button_ID, Button_State));
		}
	}
	#endregion

	#region Delegates
	public delegate void SerialChangedEventHandler(SerialChangeEventArgs e);
	#endregion

	#region Enum
	enum Debug_Options
	{
		None,								//Don't do anything with debug information
		Console,							//Output debug information to the console
		Error_Log,							//Send debug information to the error log
		Both								//Send debug infomation to both the console and error log
	};
	#endregion


	public class Flic
	{
		#region Declarations
		private static HttpServer Server;
		private static bool Server_Running = false;
		private static Debug_Options Debug;
		private static string Processor_IP;
		private static string Processor_Port;
		#endregion

		//****************************************************************************************
		// 
		//  Flic	-	Default Constructor
		// 
		//****************************************************************************************
		public Flic()
		{
		}

		//****************************************************************************************
		// 
		//  Initialize	-	Initialization
		// 
		//****************************************************************************************
		public short Initialize(string Processor_IP, string Processor_Port, short Debug)
		{
			#region Save Parameters
			Flic.Processor_IP = Processor_IP;
			Flic.Processor_Port = Processor_Port;
			#endregion

			Set_Debug_Message_Output(Debug);

			#region Create Server for capturing responses from Flic Devices
			if (Server_Running == false)                                        //don't create server if already running
			{
				if (Create_Server(Processor_IP, Processor_Port) == false)
				{
					Debug_Message("Initialize", "Create Server Failed");
					return 0;
				}
			}
			#endregion

			Debug_Message("Initialize", "SUCCESS");
			return 1;
		}

		//****************************************************************************************
		// 
		//  Create_Server	-	Setup http server to receive status messages from Flic devices
		// 
		//****************************************************************************************
		private bool Create_Server(string Processor_IP, string Processor_Port)
		{
			try
			{
				//Create a new instance of a server
				Server = new HttpServer();
				//Set the server's IP address
				Server.ServerName = Processor_IP;
				//Set the server's port
				Server.Port = int.Parse(Processor_Port);
				//Assign an event handling method to the server
				Server.OnHttpRequest += new OnHttpRequestHandler(HTTPRequestEventHandler);
				Server.Active = true;
				//save that server is running so initialization can possibly be run again to get device status
				Server_Running = true;
			}
			catch (Exception e)
			{
				CrestronConsole.PrintLine("Flic - Create_Server - Can't create http server: " + e);
				Crestron.SimplSharp.ErrorLog.Error("Flic - Create_Server - Can't create http server: " + e + "\n");
				Server.Active = false;
				return false;
			}

			return true;
		}

		//****************************************************************************************
		// 
		//  HTTPRequestEventHandler	-	Handler to receive messages sent from Flic Devices 
		// 
		//****************************************************************************************
		private void HTTPRequestEventHandler(Object sender, OnHttpRequestArgs requestArgs)
		{
			//Get IP Address of Flic device that sent message
			string Device_IP = requestArgs.Connection.RemoteEndPointAddress;
			string s = requestArgs.Request.Path.ToUpper();
			Debug_Message("HTTPRequestEventHandler", "Device_IP = " + Device_IP);
			Debug_Message("HTTPRequestEventHandler", "Path = " + s);

			#region Parse
			string Button_ID = Parse_Data_Substring(s, "", "/ID/", "/");
			string Button_State = Parse_Data_Substring(s, "", "/STATE/", "/");
			#endregion

			//pass data back to S+
			SignalChangeEvents.SerialValueChange(Button_ID, Button_State);
		}

		//****************************************************************************************
		// 
		//  Parse_Data_Substring	-	Parse Data Element from Json
		// 
		//****************************************************************************************
		private string Parse_Data_Substring(string s, string section, string id, string ending_char)
		{
			int index1, index2, section_index;

			//if data element located within a specific section of json, go to that section
			if (section != "")
			{
				section_index = s.IndexOf(section, 0);
				if (section_index == -1)
				{
					//CrestronConsole.PrintLine("Flic - Parse_Data_Substring - Unable to Locate " + section + " in " + s);
					//Crestron.SimplSharp.ErrorLog.Error("Flic - Parse_Data_Substring - Unable to Locate " + section + " in " + s);
					return "";
				}
				else
				{
					section_index += section.Length;
				}
			}
			else
			{
				section_index = 0;
			}

			//get index to start of value
			index1 = s.IndexOf(id, section_index);
			if (index1 == -1)
			{
				//CrestronConsole.PrintLine("Flic - Parse_Data_Substring - Unable to Locate " + id + " in " + s);
				//Crestron.SimplSharp.ErrorLog.Error("Flic - Parse_Data_Substring - Unable to Locate " + id + " in " + s);
				return "";
			}
			else
			{
				index1 += id.Length;
			}

			//get index to end of value
			index2 = s.IndexOf(ending_char, (index1 + 1));
			if (index2 == -1)
			{
				CrestronConsole.PrintLine("Flic - Parse_Data_Substring - Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
				Crestron.SimplSharp.ErrorLog.Error("Flic - Parse_Data_Substring - Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
				return "";
			}

			//get value substring and pass it back
			return s.Substring(index1, index2 - index1);
		}

		//****************************************************************************************
		// 
		//  Set_Debug_Message_Output	-	Save whether debug messages will be output
		//									to console, error log, both, or not sent
		//									0 = None, 1 = Console, 2 = Error Log, 3 = Both
		// 
		//****************************************************************************************
		public void Set_Debug_Message_Output(short Debug)
		{
			//Save debug message setting as an enum
			switch (Debug)
			{
				case 0:
					Flic.Debug = Debug_Options.None;
					break;

				case 1:
					Flic.Debug = Debug_Options.Console;
					break;

				case 2:
					Flic.Debug = Debug_Options.Error_Log;
					break;

				case 3:
					Flic.Debug = Debug_Options.Both;
					break;
			}
		}

		//****************************************************************************************
		// 
		//  Debug_Message	-	Send Debug Message to Console or Error Log
		//						Depending on Selection
		// 
		//****************************************************************************************
		private void Debug_Message(string Name, string s)
		{
			const int characters_per_line = 250;
			int start_index = 0;
			int length = characters_per_line;

			//json responses are too large for Simpl Debugger to display on a single line
			//so, we break them up into chunks of 250 characters to be printed on 1 line
			while (start_index < s.Length)
			{
				if ((start_index + characters_per_line) > s.Length)
				{
					length = s.Length - start_index;
				}

				string sub = s.Substring(start_index, length);

				if ((Debug == Debug_Options.Console) || (Debug == Debug_Options.Both))
				{
					CrestronConsole.PrintLine("Flic - " + Name + " - " + sub);
				}

				if ((Debug == Debug_Options.Error_Log) || (Debug == Debug_Options.Both))
				{
					Crestron.SimplSharp.ErrorLog.Notice("Flic - " + Name + " - " + sub + "\n");
				}

				start_index += characters_per_line;
			}
		}
	}
}
